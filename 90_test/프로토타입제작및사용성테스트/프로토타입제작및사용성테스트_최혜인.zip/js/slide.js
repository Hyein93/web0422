$(function () {
    $('.slider').bxSlider({
        autoControls: false,
        auto: true,
    });
});