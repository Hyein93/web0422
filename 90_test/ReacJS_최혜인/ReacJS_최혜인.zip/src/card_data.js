const cards = [
    {
        cimg: "https://search.pstatic.net/common?quality=75&direct=true&src=https%3A%2F%2Fmovie-phinf.pstatic.net%2F20240604_268%2F1717477722170vJO6X_JPEG%2Fmovie_image.jpg",
        ctit: "핸섬가이즈",
        crate: 8.6,
        cprice: "대여 11,000",
    },
    {
        cimg: "https://search.pstatic.net/common?quality=75&direct=true&src=https%3A%2F%2Fmovie-phinf.pstatic.net%2F20240603_250%2F1717391161610hLGGJ_JPEG%2Fmovie_image.jpg",
        ctit: "탈주",
        crate: 8.1,
        cprice: "대여 11,000",
    },
    {
        cimg: "https://search.pstatic.net/common?quality=75&direct=true&src=https%3A%2F%2Fmovie-phinf.pstatic.net%2F20240705_147%2F1720142916385Hwze0_JPEG%2Fmovie_image.jpg",
        ctit: "하이재킹",
        crate: 8.7,
        cprice: "구매 10,900",
    },
    {
        cimg: "https://search.pstatic.net/common?quality=75&direct=true&src=https%3A%2F%2Fmovie-phinf.pstatic.net%2F20240520_131%2F1716182868503x7WoW_JPEG%2Fmovie_image.jpg",
        ctit: "존 오브 인터레스트",
        crate: 8.5,
        cprice: "대여 11,000",
    },
    {
        cimg: "https://search.pstatic.net/common?quality=75&direct=true&src=https%3A%2F%2Fmovie-phinf.pstatic.net%2F20240425_256%2F17140073560223JK9r_JPEG%2Fmovie_image.jpg",
        ctit: "범죄도시4",
        crate: 7.4,
        cprice: "대여 11,000",
    },
];